const filmes = [
  {
    titulo: 'O Auto da Compadecida',
    ano: 2000,
    diretor: 'Guel Arraes',
    elenco: [
      'Selton Mello',
      'Mateus Nachtergaele',
      'Marco Nanini',
      'Fernanda Montenegro',
    ],
  },
  {
    titulo: 'Carandiru',
    ano: 2001,
    diretor: 'Hector Babenco',
    elenco: [
      'Wagner Moura',
      'José Carlos Vasconcelos',
      'Ailton Graça',
      'Caio Blat',
    ],
  },
  {
    titulo: 'Aquarius',
    ano: 2012,
    diretor: 'Kléber Mendonça Filho',
    elenco: [
      'Sônia Braga',
      'Humberto Carrão',
      'Maeve Jinkings',
      'Bárbara Colen',
    ],
  },
]

// escreva seu código abaixo 👇🏻

//EXPLICAO DO ESQUENTA:
//       // indice=  0  1   2    3   4   //FOR IN = indice
// const numeros = [14, 67, 89, 15, 23]; //FOR OF = valor



// for(let i in numeros){
//     console.log(i);
// }

// for(let i of numeros){
//     console.log(i);
// }

// const array = ["maçã", "banana", "uva"];

// for (const value of array) {
//   console.log(value);
//   console.log(array)
// }

//PRATICA GUIADA

//Vamos criar um código que cria e recebe um array 
//com os últimos 4 resultados da Mega-sena. 
//Portanto, precisaremos de um array de arrays.

//Depois, devemos verificar se o número de itens do array 
//que contém os jogos contém exatamente 4 resultados
//Caso seja diferente, imprima que é necessário alterar 
//o número de itens do array.


const megaSena = [
//0, 1,2  
  [1,3,5], //sortei 1
  [0,2,4,6], //sortei 2
  [4,8,12,18], //sortei 3
  [5,10,15,20] //sortei 4
]

// Agora, devemos imprimir cada um dos jogos, no seguinte formato:
// Sorteio 1: num1, num2, num3, num4, num5, num6

// if(megaSena.length === 4){
//   //verificado, contem exatamente 4 resultados

//   for(let i=0; i<megaSena.length;i++){ //array mega sena
//     // console.log(`sorteio ${i+1}: ${megaSena[i]}`)
//     let sorteio = `sorteio ${i}: `
//     for(let j=0; j<megaSena[i].length; j++){ // array cada sorteio
//       sorteio += megaSena[i][j] + ", "
//       // console.log(megaSena[i][j])
//       // console.log(j)
//     }
//     console.log(sorteio)
//   }

// }else{
//   console.log("É necessário alterar o número de itens do array.")
// }



//PRATICA GUIADA 2 e 3

if(megaSena.length === 4){
  //verificado, contem exatamente 4 resultados

  for(let i in megaSena){ //array mega sena
    let sorteio = `sorteio ${Number(i)+1}: `
    for(let j of megaSena[i]){ // array cada sorteio
      sorteio += j + ", "
    }
    console.log(sorteio)
  }

}else{
  console.log("É necessário alterar o número de itens do array.")
}


//  EXERCICIO DICAÇÃO
//Use o array de filmes que esta no template: 
// Crie um laço for para exibir o título, o ano e o diretor dos filmes como uma String
// Crie um laço for dentro do primeiro, para concatenar o elenco numa String
// A saída deve se parecer com:
// “O Homem que copiava, de 2003, dirigido por Jorge Furtado”
// “Tem no elenco: Lázaro Ramos, Leandra Leal, Pedro Cardoso”

  
for(let i = 0; i<filmes.length; i++){
  // console.log(filmes[i])
  console.log(`${filmes[i].titulo}, de ${filmes[i].ano}, dirigido por ${filmes[i].diretor}`)
  let listaElenco= `Tem no elenco: `
  for(let j = 0; j<filmes[i].elenco.length; j++){
    // console.log(`Tem no elenco: ${filmes[i].elenco[j]}`) // pode ficar fora do segundo laço
    listaElenco += filmes[i].elenco[j] + ", "
  }
  console.log(listaElenco)
}
